export default function PricingSection() {
  return (
    <section className="py-20 px-4 bg-white text-center">

      <h1 className="text-3xl md:text-4xl font-bold mb-4">
        Slăbește simplu, fără sală — chiar dacă nu ai timp
      </h1>

      <p className="text-gray-600 mb-4">
        Antrenamente acasă + plan alimentar simplu → rezultate reale în 60 zile
      </p>

      <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-700 mb-10">
        <span>✔ fără echipamente</span>
        <span>✔ fără complicații</span>
        <span>✔ pentru femei ocupate</span>
      </div>

      <h2 className="text-2xl font-semibold mb-2">
        Alege varianta potrivită pentru tine
      </h2>
      <p className="text-gray-500 mb-10">
        Simplu. Rapid. Rezultate reale.
      </p>

      <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-6">

        <div className="border border-green-100 rounded-2xl p-8 shadow-sm">
          <h3 className="text-xl font-semibold mb-2">Basic Plan</h3>

          <p className="text-3xl font-bold">
            599 RON <span className="text-base font-normal">/ 60 zile</span>
          </p>
          <p className="line-through text-gray-400 mb-4">999 RON</p>

          <ul className="text-left text-gray-700 space-y-2 mb-6">
            <li>✔ Antrenamente live 3x / săptămână</li>
            <li>✔ Antrenamente acasă</li>
            <li>✔ Program 30–45 minute</li>
            <li>✔ Focus abdomen</li>
            <li>✔ Plan alimentar simplu</li>
          </ul>

          <button className="w-full bg-black text-white py-3 rounded-xl hover:bg-green-200 hover:text-black">
            Încep acum
          </button>
        </div>

        <div className="border-2 border-green-300 bg-green-50 rounded-2xl p-8 shadow-md">
          <p className="text-sm font-semibold text-green-500 mb-2">RECOMANDAT</p>
          <h3 className="text-xl font-semibold mb-2">Pro Plan</h3>

          <p className="text-3xl font-bold">
            899 RON <span className="text-base font-normal">/ 60 zile</span>
          </p>
          <p className="line-through text-gray-400 mb-4">1399 RON</p>

          <ul className="text-left text-gray-700 space-y-2 mb-6">
            <li>✔ Tot din Basic</li>
            <li>✔ Plan personalizat</li>
            <li>✔ Macronutrienți</li>
            <li>✔ Monitorizare progres</li>
            <li>✔ Suport</li>
          </ul>

          <button className="w-full bg-black text-white py-3 rounded-xl hover:bg-green-200 hover:text-black">
            Vreau rezultate mai rapide
          </button>
        </div>

      </div>

      <div className="max-w-md mx-auto mt-12 border border-green-100 rounded-2xl p-8 shadow-sm">
        <h3 className="text-xl font-semibold mb-2">
          Plan Nutrițional
        </h3>

        <p className="text-2xl font-bold mb-4">199 RON</p>

        <ul className="text-left text-gray-700 space-y-2 mb-6">
          <li>✔ Calcul caloric personalizat</li>
          <li>✔ Mese simple și rapide</li>
          <li>✔ Adaptat stilului de viață</li>
        </ul>

        <button className="w-full bg-black text-white py-3 rounded-xl hover:bg-green-200 hover:text-black">
          Vreau nutriția
        </button>
      </div>

    </section>
  );
}
